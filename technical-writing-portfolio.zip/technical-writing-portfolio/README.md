# Minnie Kaur — Technical Writing Portfolio

Senior Technical Writer | Documentation & Knowledge Management | Docs-as-Code | AI-ready content

This portfolio contains original, sanitized samples that demonstrate how I approach complex technical documentation. The scenarios are representative of enterprise work, but company names, systems, credentials, data, and internal implementation details have been removed or fictionalized.

## What this portfolio demonstrates

- Developer and API documentation
- Data migration and decommissioning documentation
- QA/UAT workflows and validation guidance
- AI-ready knowledge architecture and governance
- Operational runbooks
- Docs-as-code practices with Markdown, Git, YAML, and Mermaid

## Featured samples

| Sample | What it demonstrates |
|---|---|
| [SQL Server to Snowflake migration](sql-snowflake-migration/README.md) | Architecture, migration planning, validation, cutover, rollback, stakeholder-ready documentation |
| [QA/UAT validation guide](qa-uat-documentation/README.md) | Per-table validation, ownership, evidence, handoffs, acceptance criteria |
| [REST API documentation](api-documentation/README.md) | Task-oriented developer docs, authentication, errors, examples, OpenAPI |
| [AI knowledge management framework](ai-knowledge-management/README.md) | Taxonomy, metadata, source-of-truth rules, retrieval readiness, governance |
| [Incident runbook](runbooks/data-pipeline-incident.md) | Troubleshooting, escalation, recovery, verification |

## Documentation approach

I treat documentation as a product: understand the audience and task, establish a source of truth, design information for findability, validate technical accuracy with SMEs, and maintain content through a defined lifecycle. For developer documentation, I prefer docs-as-code where it improves reviewability, traceability, and collaboration.

## Tools & technologies

Markdown · Git/GitHub · Jira · Confluence · OpenAPI · REST APIs · SQL · Snowflake · AWS · Terraform · Mermaid · information architecture · knowledge management

## About the samples

These are portfolio artifacts, not copies of proprietary documentation. They combine original writing with generalized patterns from my professional experience.
