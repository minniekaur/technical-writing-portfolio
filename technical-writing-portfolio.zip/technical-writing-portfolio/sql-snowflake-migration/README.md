# SQL Server to Snowflake Migration & Decommissioning

## Overview

This sample documents a phased migration from a legacy SQL Server reporting environment to Snowflake. It is designed for engineers, QA analysts, data owners, and business stakeholders who need a shared view of scope, validation, cutover, and decommissioning controls.

> **Portfolio note:** Names, identifiers, schemas, dates, and implementation details are fictionalized.

## Goals

- Migrate actively used datasets without interrupting reporting.
- Validate schema, data quality, and business behavior before cutover.
- Maintain traceability from source table to Snowflake object.
- Provide rollback criteria for failed cutovers.
- Decommission legacy assets only after business sign-off.

## Lifecycle

```mermaid
flowchart LR
    A[Inventory source table] --> B[Confirm owner & dependency]
    B --> C[Ingest to Snowflake]
    C --> D[Transform]
    D --> E[QA validation]
    E -->|Pass| F[UAT]
    E -->|Fail| C
    F -->|Approved| G[Cutover]
    F -->|Changes required| D
    G --> H[Monitor]
    H --> I[Decommission legacy object]
```

## Migration controls

| Stage | Required evidence | Exit criterion |
|---|---|---|
| Inventory | Source, target, owner, dependency | Scope confirmed |
| Ingestion | Load status and timestamp | Data available in target |
| Transformation | Mapping and business rules | Transformation reviewed |
| QA | Schema + metric comparison | QA acceptance criteria met |
| UAT | Business validation evidence | Data owner approval |
| Cutover | Change record + rollback plan | Consumers moved to target |
| Decommission | Dependency confirmation | No approved legacy dependency remains |

## Large-table QA strategy

For high-volume tables, validation begins with inexpensive structural checks before row-intensive comparisons.

1. Compare column names, order where relevant, data types, and nullability expectations.
2. Stop and document structural mismatches before running expensive checks.
3. Compare agreed numerical aggregates and record counts at the required grain.
4. Avoid high-cost uniqueness scans when they do not add meaningful assurance.
5. Record every accepted difference in the migration tracker.

This ordering reduces wasted runtime while preserving explicit acceptance criteria.

## Cutover checklist

- [ ] QA passed and evidence attached.
- [ ] UAT owner approved the target object.
- [ ] Consumer connections and service authentication are ready.
- [ ] Refresh schedule is documented.
- [ ] Monitoring is enabled.
- [ ] Rollback owner and trigger are documented.
- [ ] Legacy dependency check is complete.
- [ ] Decommission approval is recorded.

## Rollback triggers

Rollback or pause cutover when a critical consumer cannot connect, material metrics differ beyond the approved tolerance, required columns are missing, or the target misses its agreed refresh SLA.

## Documentation design decisions

The document separates *technical validation* from *business acceptance*. QA proves that the target conforms to defined technical expectations; UAT confirms that the migrated data supports the intended business use. This prevents ambiguous ownership at sign-off.
