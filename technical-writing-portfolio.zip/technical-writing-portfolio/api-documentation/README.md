# Inventory REST API

A fictional API sample demonstrating task-oriented developer documentation.

## Base URL

```text
https://api.example.com/v1
```

## Authentication

Send a bearer token in the `Authorization` header.

```bash
curl https://api.example.com/v1/products \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

Never place access tokens in URLs, source control, or client-side logs.

## List products

`GET /products`

Optional query parameters:

| Parameter | Type | Description |
|---|---|---|
| `limit` | integer | Number of records to return; default 25, maximum 100 |
| `cursor` | string | Cursor returned by the previous response |
| `status` | string | Filter by `active` or `inactive` |

### Example response

```json
{
  "data": [
    {
      "id": "prd_1042",
      "name": "Reusable Bottle",
      "status": "active",
      "quantity": 84
    }
  ],
  "next_cursor": "eyJpZCI6MTA0Mn0="
}
```

## Create a product

`POST /products`

```json
{
  "name": "Reusable Bottle",
  "sku": "BOT-001",
  "quantity": 100
}
```

A successful request returns `201 Created`.

## Errors

| Status | Meaning | Recommended action |
|---|---|---|
| 400 | Invalid request | Correct the field identified in the error response |
| 401 | Authentication failed | Verify the token is present and valid |
| 404 | Resource not found | Verify the resource ID |
| 409 | Conflict | Check for a duplicate SKU or conflicting update |
| 429 | Rate limit exceeded | Retry after the `Retry-After` interval |
| 500 | Server error | Retry with backoff; contact support if persistent |

See [`openapi.yaml`](openapi.yaml) for the machine-readable definition.
